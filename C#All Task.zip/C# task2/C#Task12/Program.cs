﻿namespace FibonacciSeries
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter the number of elements to print: ");
            int numberOfElements = int.Parse(Console.ReadLine());

            int firstNumber = 0, secondNumber = 1;

            Console.Write(firstNumber + " " + secondNumber + " ");

            for (int i = 2; i < numberOfElements; i++)
            {
                int nextNumber = firstNumber + secondNumber;
                Console.Write(nextNumber + " ");
                firstNumber = secondNumber;
                secondNumber = nextNumber;
            }

            Console.ReadKey();
        }
    }
}
