﻿using System;
namespace Program{
class Program
{
    static void Main()
    {
        Console.Write("Enter the height of the letter T: ");
        int height = int.Parse(Console.ReadLine());

        for (int i = 0; i < height; i++)
        {
            Console.Write("*");
        }
        Console.WriteLine();
        int middle = height / 2;
        for (int i = 1; i < height; i++)
        {
            for (int j = 0; j < height; j++)
            {
                if (j == middle)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(" ");
                }
            }
            Console.WriteLine();
        }
    }
}
}
