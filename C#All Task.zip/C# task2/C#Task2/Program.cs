﻿
namespace DayCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            
            DateTime today = DateTime.Today;

        
            DateTime futureDate = today.AddDays(40);

            
            string dayOfWeek = futureDate.DayOfWeek.ToString();

            Console.WriteLine($"40 days from today will be a {dayOfWeek}.");
        }
    }
}
