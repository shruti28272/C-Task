﻿using System;

class  Program
{
    static void Main()
    {
        // enter your name
        Console.Write("Enter your name: ");
        string name = Console.ReadLine();

         // enter your age
        Console.Write("Enter your age: ");
        int age = int.Parse(Console.ReadLine());

    
        int currentYear = DateTime.Now.Year;
        int birthYear = currentYear - age;

        
        Console.WriteLine($"Hello, {name}! You were born in the year {birthYear}.");
    }
}
