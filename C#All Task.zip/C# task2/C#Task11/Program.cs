﻿
using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Choose the type of character for your passward:");
        Console.WriteLine("1. Only Letters");
        Console.WriteLine("2. Only Numbers");
        Console.WriteLine("3. Combination of Letters and Numbers");
        Console.Write("Enter your choice (1,2 or 3): ");
        int choice = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter the desired length of the string: ");
        int length = Convert.ToInt32(Console.ReadLine());

        string result = GenerateString(choice, length);

        Console.WriteLine($"Generated String: {result}");
    }

    static string GenerateString(int choice, int length)
    {
        string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        string numbers = "0123456789";
        string result = "";

        Random random = new Random();

        switch (choice)
        {
            case 1:
                // Only Letters
                for (int i = 0; i < length; i++)
                {
                    result += letters[random.Next(letters.Length)];
                }
                break;

            case 2:
                // Only Numbers
                for (int i = 0; i < length; i++)
                {
                    result += numbers[random.Next(numbers.Length)];
                }
                break;

            case 3:
                // Combination of Letters and Numbers
                for (int i = 0; i < length; i++)
                {
                    if (random.Next(2) == 0)
                    {
                        result += letters[random.Next(letters.Length)];
                    }
                    else
                    {
                        result += numbers[random.Next(numbers.Length)];
                    }
                }
                break;

            default:
                Console.WriteLine("Invalid choice!");
                break;
        }

        return result;
    }
}
