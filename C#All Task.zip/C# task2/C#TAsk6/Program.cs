﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Input the first number of G.P. series: ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Input the number of terms in the G.P. series:");
        double r = Convert.ToDouble(Console.ReadLine());

        Console.Write("Input the common ratio of G.P. series: ");
        int num = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("The GP series is:");
        for(int i=0;i<num; i++)
        {
        double term = a*Math.Pow(r,i);
        
        Console.WriteLine(term + " ");
}
    }
}

