﻿class BaseClass
{
    public virtual void Show()
    {
        Console.WriteLine("Base class");
    }
}

class Derived : BaseClass
{
    public override void Show()
    {
        Console.WriteLine("Derived class");
    }
}

class Program
{
    static void Main()
    {
        BaseClass obj = new BaseClass();
        obj.Show();

        obj = new Derived();
        obj.Show();
    }
}
