﻿ using System;
 
 
 namespace Calculator
{
    class Calc
    
    {
        static void Main(string[] args)
        {
            string value;
            do
            {
                Console.Write("Enter the first number: ");
                int num1 = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter the second number: ");
                int num2 = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter the operator (+, -, *, /): ");
                string symbol = Console.ReadLine();

                switch (symbol)
                {
                    case "+":
                        Console.WriteLine($"Addition: {num1 + num2}");
                        break;
                    case "-":
                        Console.WriteLine($"Subtraction: {num1 - num2}");
                        break;
                    case "*":
                        Console.WriteLine($"Multiplication: {num1 * num2}");
                        break;
                    case "/":
                        if (num2 != 0)
                            Console.WriteLine($"Division: {num1 / num2}");
                        else
                            Console.WriteLine("Cannot divide by zero!");
                      
                    break;
                    default:
                        Console.WriteLine("Invalid operator.");
                        break;
                }

                Console.Write("Do you want to continue (y/n)? ");
                value = Console.ReadLine();
            } while (value.ToLower() == "y");
        }
    }
}
