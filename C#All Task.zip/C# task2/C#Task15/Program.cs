﻿using System;

namespace Mypet
{
 
  abstract class Animal
  {
      String name;

    public abstract void animalSound();

  }
  class Cat : Animal
  {
    public override void animalSound()
    {
      
      Console.WriteLine("The Cat Says Mewo mewo");
    }
    }
  
   class Dog : Animal
  {
    public override void animalSound()
    {
     
      Console.WriteLine("The Dog says: bho bho");
    }
  }
  

  class Program
  {
    static void Main(string[] args)
    {
    
      Cat myCat = new Cat(); 
      Dog myDog = new Dog();
      myCat.animalSound();
      myDog.animalSound();


      
    }
  }
}