﻿using System;

class Marks
{
    static void Main()
    {
       
        Console.Write("Enter marks in Mathematics: ");
        int math = int.Parse(Console.ReadLine());

        Console.Write("Enter marks in Physics: ");
        int phy = int.Parse(Console.ReadLine());

        Console.Write("Enter marks in Chemistry: ");
        int chem = int.Parse(Console.ReadLine());

       
        int total = math + phy + chem;
        int mathPhyTotal = math + phy;

        if (math >= 65 && phy >= 55 && chem >= 50 && (total >= 180 || mathPhyTotal >= 140))
        {
            Console.WriteLine("The candidate is eligible for admission.");
        }
        else
        {
            Console.WriteLine("The candidate is not eligible for admission.");
        }
    }
}
