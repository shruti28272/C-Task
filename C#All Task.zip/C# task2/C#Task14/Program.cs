﻿namespace EmployeeData
{
   
    struct Employee
    {
        public string Name;
        public int DayOfBirth;
        public int MonthOfBirth;
        public int YearOfBirth;
    }

    class Program
    {
        static void Main()
        {
            int numEmployees = 2; // Number of employees

            // Create an array to store employee data
            Employee[] employees = new Employee[numEmployees];

            // Input data for each employee
            for (int i = 0; i < numEmployees; i++)
            {
                Console.WriteLine($"Enter details for Employee {i + 1}:");

                Console.Write("Name of the employee: ");
                employees[i].Name = Console.ReadLine();

                Console.Write("Input day of birth: ");
                employees[i].DayOfBirth = int.Parse(Console.ReadLine());

                Console.Write("Input month of birth: ");
                employees[i].MonthOfBirth = int.Parse(Console.ReadLine());

                
Console.Write("Input year of birth: ");
                employees[i].YearOfBirth = int.Parse(Console.ReadLine());

                Console.WriteLine();
            }

            // Display the stored employee data
            Console.WriteLine("\nEmployee Data:");
            for (int i = 0; i < numEmployees; i++)
            {
                Console.WriteLine($"Employee {i + 1}:");
                Console.WriteLine($"Name: {employees[i].Name}");
                Console.WriteLine($"Date of Birth: {employees[i].DayOfBirth}/{employees[i].MonthOfBirth}/{employees[i].YearOfBirth}");
                Console.WriteLine();
            }

            // Wait for user input before exiting
            Console.ReadLine();
        }
    }
}
