﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        int number = int.Parse(Console.ReadLine());

        Console.WriteLine($"Cubes of numbers from 1 to {number}:");

        for (int i = 1; i <= number; i++)
        {
            int cube = i * i * i;
            Console.WriteLine($"Number is : {i} and  cube of {i} is: {cube} ");
        }
    }
}
