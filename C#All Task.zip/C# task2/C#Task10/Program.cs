﻿using System;

namespace MaxMinArrayElements
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input the number of elements to be stored in the array: ");
            int numElements = Convert.ToInt32(Console.ReadLine());

            // Create an array of the specified size
            int[] arr = new int[numElements];

            // Input elements
            for (int i = 0; i < numElements; i++)
            {
                Console.Write($"Input element - {i}: ");
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            // Find maximum and minimum elements
            int maxElement = arr[0];
            int minElement = arr[0];

            for (int i = 1; i < numElements; i++)
            {
                if (arr[i] > maxElement)
                {
                    maxElement = arr[i];
                }
                else if (arr[i] < minElement)
                {
                    minElement = arr[i];
                }
            }


            // Display results
            Console.WriteLine($"Maximum element: {maxElement}");
            Console.WriteLine($"Minimum element: {minElement}");

            // Wait for user input before exiting
            Console.ReadLine();
        }
    }
}
